﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai15_p41
{
    class Program
    {
        static double TongN_mu_N(int n)
        {
            double s = 0;
            for (int i = 1; i <= n; i++)
                s = s+ Math.Pow(i, i);
            return s;
        }
        static void Main(string[] args)
        {
            int n;
            do
            {
                Console.Write("Nhap vao 1 so nguyen duong: ");
                n = int.Parse(Console.ReadLine());
            } while (n <= 0);
            Console.Write("Tong = {0}", TongN_mu_N(n));
            Console.ReadKey();
        }
    }
}
