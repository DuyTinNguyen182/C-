﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai10_p40
{
    class Program
    {
        static void DemUoc(int n)
        {
            Console.Write("Cac uoc cua {0} la: ", n);
            for (int i=1; i<=n; i++)
            {
                if (n % i == 0)
                    Console.Write(i +" ");
            }
        }
        static void Main(string[] args)
        {
            int n;
            do
            {
                Console.Write("Nhap vao 1 so nguyen duong: ");
                n = int.Parse(Console.ReadLine());
            } while (n <= 0);
            DemUoc(n);
            Console.ReadKey();
        }
    }
}
