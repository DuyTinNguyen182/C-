﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai12_p40
{
    class Program
    {
        static int TongN(int n)
        {
            int t = 0;
            for (int i = 1; i <= n; i++)
                t = t + i;
            return t;
        }
        static void Main(string[] args)
        {
            int n;
            do
            {
                Console.Write("Nhap vao 1 so nguyen duong: ");
                n = int.Parse(Console.ReadLine());
            } while (n <= 0);
            Console.Write("Tong tu 1 den {0} = {1}", n, TongN(n));
            Console.ReadKey();
        }
    }
}
