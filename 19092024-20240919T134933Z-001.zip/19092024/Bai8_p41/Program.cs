﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai8_p41
{
    class Program
    {
        static void TinhTien(int n, int a)
        {
            int t = 0;
            if (n <= 10)
            {
                if (a == 1)
                    t = 250000 * n;
                else if (a == 2)
                    t = 200000 * n;
                else
                    t = 150000 * n;
            }
            else
            {
                if (a == 1)
                    t = 250000 * n;
                else if (a == 2)
                    t = 200000 * n;
                else
                    t = 150000 * n;
                t = t - (t / 100 * 10);
            }
            Console.Write("Thanh tien: {0}d", t);
        }
        static void Main(string[] args)
        {
            int a, n;
            do
            {
                Console.Write("Nhap so ngay thue:");
                n = int.Parse(Console.ReadLine());
            } while (n <= 0);
            Console.WriteLine("Loai A: 250.000d/ngay. Nhap 1");
            Console.WriteLine("Loai B: 200.000d/ngay. Nhap 2");
            Console.WriteLine("Loai C: 150.000d/ngay. Nhap 3");
            Console.Write("Nhap loai phong: ");
            a = int.Parse(Console.ReadLine());
            TinhTien(n, a);
            Console.ReadKey();
        }
    }
}
