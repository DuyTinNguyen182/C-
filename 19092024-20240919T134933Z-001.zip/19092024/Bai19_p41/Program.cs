﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai19_p41
{
    class Program
    {
        static void nhap(int n, int[] a)
        {
            for (int i = 0; i < n; i++)
            {
                Console.Write("Nhap phan tu thu {0}: ", i + 1);
                a[i] = int.Parse(Console.ReadLine());
            }
        }
        static void xuat(int n, int[] a)
        {
            Console.Write("Mang vua nhap la:");
            for (int i = 0; i < n; i++)
            {
                Console.Write("\t" + a[i]);
            }
        }
        static void dem(int n, int[] a)
        {
            int d = 0, am = 0, k = 0;
            for(int i=0; i<n; i++)
            {
                if (a[i] > 0)
                    d++;
                else if (a[i] < 0)
                    am++;
                else
                    k++;
            }
            Console.Write("\nMang co {0} so duong", d);
            Console.Write("\nMang co {0} so am", am);
            Console.Write("\nMang co {0} so 0", k);
        }
        static void Main(string[] args)
        {
            int n;
            do
            {
                Console.Write("Nhap do dai mang: ");
                n = int.Parse(Console.ReadLine());
            } while (n <= 0);
            int[] a = new int[n];
            nhap(n, a);
            xuat(n, a);
            dem(n, a);
            Console.ReadKey();
        }
    }
}
