﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai11_40
{
    class Program
    {
        static int UocC(int a, int b)
        {
            while (a * b != 0)
            {
                if (a > b)
                    a = a % b;
                else
                    b = b % a;
            }
            return a+b;
        }
        static void Main(string[] args)
        {
            int n1, n2;
            Console.Write("Nhap vao so thu nhat: ");
            n1 = int.Parse(Console.ReadLine());
            Console.Write("Nhap vao so thu hai: ");
            n2 = int.Parse(Console.ReadLine());
            Console.Write("Uoc chung lon nhat cua {0} va {1} la: {2}", n1, n2, UocC(n1, n2));
            Console.ReadKey();
        }
    }
}
