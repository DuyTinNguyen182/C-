﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai13_p41
{
    class Program
    {
        static double Tong1phanN(int n)
        {
            double t = 0;
            for(int i=1; i<=n; i++)
            {
                t = t + 1 / Math.Pow(2, i);
            }
            return t;
        }
        static void Main(string[] args)
        {
            int n;
            do
            {
                Console.Write("Nhap vao 1 so nguyen duong: ");
                n = int.Parse(Console.ReadLine());
            } while (n <= 0);
            Console.Write("Tong = {0}", Tong1phanN(n));
            Console.ReadKey();
        }
    }
}
