﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai7_p40
{
    class Program
    {
        static void DocSo(int n)
        {
            int c, dv;
            c = n / 10;
            dv = n % 10;
            switch (c)
            {
                case 1:
                    Console.Write("Muoi");
                    break;
                case 2:
                    Console.Write("Hai muoi");
                    break;
            }
        }
        static void Main(string[] args)
        {
            int n;
            do
            {
                Console.Write("Nhap vao 1 so nguyen co 2 chu so: ");
                n = int.Parse(Console.ReadLine());
            } while (n < 10 || n > 99);
            Console.ReadKey();
        }
    }
}
