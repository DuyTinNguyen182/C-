﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai14_p41
{
    class Program
    {
        static void BangCC(int n)
        {
            Console.WriteLine("Bang cuu chuong {0}", n);
            for (int i = 1; i <= 10; i++)
                Console.WriteLine("{0} x {1} = {2}", n, i, n * i);
        }
        static void Main(string[] args)
        {
            int n;
            do
            {
                Console.Write("Nhap so bang cuu chuong: ");
                n = int.Parse(Console.ReadLine());
            } while (n < 1 || n > 9);
            BangCC(n);
            Console.ReadKey();
        }
    }
}
